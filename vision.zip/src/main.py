# -*- coding: utf-8 -*-
"""钢球静态视觉测试程序。

目标：在当前固定相机、约20 cm可见轨道范围内，验证钢球检测和位置输出。

处理流程：
    Sensor灰度/RGB888采集 -> 对应的cv_lite霍夫圆检测 -> ROI/半径过滤
    -> 钢球中心 -> 相对物理中心的整数像素误差 -> LCD和控制台调试

本阶段启用K230到STM32的单向UART视觉测量；PID和舵机闭环由STM32负责。
当前相机右侧对应固定端，error_px为负；相机左侧对应舵机端，error_px为正。

使用的CanMV API：media.sensor.Sensor、media.display.Display、
media.media.MediaManager、cv_lite灰度/RGB888圆检测、CanMV Image绘图接口、
machine.FPIOA和machine.UART。
硬件：Yahboom K230 12Pin、板载摄像头/LCD、浅色轨道、钢球。
运行时：CanMV K230 Yahboom v1.8.0
"""

import gc
import os
import time

from media.display import Display
from media.media import MediaManager
from media.sensor import Sensor

import config
from communication.uart import VisionUart
from control.filter import ExponentialFilter
from utils.logger import DebugFrameSaver, log_error, log_info
from vision.ball_detector import BallDetector
from vision.geometry import pixel_position_error, position_is_safe


# =============================================================================
# 调参区：CanMV IDE只打开main.py时，优先修改这里
# =============================================================================
FIELD_TUNING_ENABLED = True

# 灰度检测比RGB888约快1.5 FPS。当前直接在灰度帧上绘制灰度标记，
# 不再先把灰度帧转换成RGB565。
TUNE_GRAYSCALE_ENABLED = True

# 蓝框必须包住钢球可运动区域，但尽量不要包住绿色底板和两端黑色机构。
# 格式：(x, y, width, height)，坐标以640x480原始图像为准。
TUNE_BALL_ROI = (10, 205, 620, 90)

# 下面是2026-07-21在当前Yahboom v1.8.0实机通过的圆检测参数。
# dp：累加器分辨率比例；min_dist：两个圆心的最小距离。
# param1：Canny高阈值；param2：圆心累加器阈值，越小越容易检出也越易误检。
TUNE_CIRCLE_DP = 1
TUNE_CIRCLE_MIN_DIST = 30
TUNE_CIRCLE_PARAM1 = 80
TUNE_CIRCLE_PARAM2 = 20
TUNE_CIRCLE_MIN_RADIUS = 8
TUNE_CIRCLE_MAX_RADIUS = 35
TUNE_CONSOLE_INTERVAL_FRAMES = 10

# -----------------------------------------------------------------------------
# 动态跟踪与滤波参数
# -----------------------------------------------------------------------------
# 没有历史位置时，在多个圆中优先选择半径最接近17 px的候选。
TUNE_BALL_EXPECTED_RADIUS = 17

# 已经跟踪到钢球后，候选圆心单帧最多允许跳动80 px。
# 太小会漏掉高速钢球，太大则可能跳到远处反光圆；先用实机运动测试验证。
TUNE_BALL_TRACK_MAX_JUMP_PX = 80

# 相邻有效帧半径最多变化8 px，排除半径突然变大的背景反光圆。
TUNE_BALL_TRACK_MAX_RADIUS_CHANGE = 8

# 连续丢失3帧后清除旧位置，允许钢球从远处重新进入ROI时被重新捕获。
# 注意：每个丢失帧都会立即输出ball_valid=0，不会等待3帧才报错。
TUNE_BALL_TRACK_LOST_RESET_FRAMES = 3

# 指数滤波系数。0.5表示当前原始位置和上一滤波结果各占一半。
# 越接近1响应越快、抖动越大；越接近0越平滑、延迟越明显。
TUNE_BALL_FILTER_ALPHA = 0.75

# 三点实测得到的物理中心和暂定安全边界。
# 当前相机画面右侧是固定端，左侧是舵机驱动端。
TUNE_BALL_TARGET_X = 361
TUNE_BALL_SAFE_LEFT_X = 60
TUNE_BALL_SAFE_RIGHT_X = 598


def _apply_field_tuning():
    """用main.py现场参数临时覆盖config.py。"""
    if not FIELD_TUNING_ENABLED:
        print("field_tuning=OFF, use config.py")
        return

    config.BALL_ROI = tuple(TUNE_BALL_ROI)
    config.BALL_GRAYSCALE_ENABLED = bool(TUNE_GRAYSCALE_ENABLED)
    # 当前Yahboom v1.8.0的cv_lite绑定要求圆检测参数为整数。
    # 独立实机例程使用dp=1成功；不要在这里转换成1.0。
    config.BALL_CIRCLE_DP = int(TUNE_CIRCLE_DP)
    config.BALL_CIRCLE_MIN_DIST = int(TUNE_CIRCLE_MIN_DIST)
    config.BALL_CIRCLE_PARAM1 = int(TUNE_CIRCLE_PARAM1)
    config.BALL_CIRCLE_PARAM2 = int(TUNE_CIRCLE_PARAM2)
    config.BALL_CIRCLE_MIN_RADIUS = int(TUNE_CIRCLE_MIN_RADIUS)
    config.BALL_CIRCLE_MAX_RADIUS = int(TUNE_CIRCLE_MAX_RADIUS)
    config.BALL_EXPECTED_RADIUS = int(TUNE_BALL_EXPECTED_RADIUS)
    config.BALL_TRACK_MAX_JUMP_PX = int(TUNE_BALL_TRACK_MAX_JUMP_PX)
    config.BALL_TRACK_MAX_RADIUS_CHANGE = int(TUNE_BALL_TRACK_MAX_RADIUS_CHANGE)
    config.BALL_TRACK_LOST_RESET_FRAMES = int(TUNE_BALL_TRACK_LOST_RESET_FRAMES)
    config.BALL_FILTER_ALPHA = float(TUNE_BALL_FILTER_ALPHA)
    config.BALL_TARGET_X = int(TUNE_BALL_TARGET_X)
    config.BALL_SAFE_LEFT_X = int(TUNE_BALL_SAFE_LEFT_X)
    config.BALL_SAFE_RIGHT_X = int(TUNE_BALL_SAFE_RIGHT_X)
    config.CONSOLE_INTERVAL_FRAMES = int(TUNE_CONSOLE_INTERVAL_FRAMES)

    if not (
        config.BALL_SAFE_LEFT_X
        < config.BALL_TARGET_X
        < config.BALL_SAFE_RIGHT_X
    ):
        raise ValueError("BALL_TARGET_X must lie inside the safe range")
    if config.BALL_FILTER_ALPHA <= 0.0 or config.BALL_FILTER_ALPHA > 1.0:
        raise ValueError("BALL_FILTER_ALPHA must be in (0, 1]")

    print("field_tuning=ON")
    print(
        "vision_format={}".format(
            "GRAYSCALE" if config.BALL_GRAYSCALE_ENABLED else "RGB888"
        )
    )
    print("ball_roi={}".format(config.BALL_ROI))
    print(
        "circle dp={} min_dist={} param1={} param2={} radius={}-{}".format(
            config.BALL_CIRCLE_DP,
            config.BALL_CIRCLE_MIN_DIST,
            config.BALL_CIRCLE_PARAM1,
            config.BALL_CIRCLE_PARAM2,
            config.BALL_CIRCLE_MIN_RADIUS,
            config.BALL_CIRCLE_MAX_RADIUS,
        )
    )
    print(
        "target_x={} safe_x={}..{} fixed_side=camera_right".format(
            config.BALL_TARGET_X,
            config.BALL_SAFE_LEFT_X,
            config.BALL_SAFE_RIGHT_X,
        )
    )
    print(
        "tracking expected_r={} max_jump={} max_dr={} lost_reset={} filter_alpha={}".format(
            config.BALL_EXPECTED_RADIUS,
            config.BALL_TRACK_MAX_JUMP_PX,
            config.BALL_TRACK_MAX_RADIUS_CHANGE,
            config.BALL_TRACK_LOST_RESET_FRAMES,
            config.BALL_FILTER_ALPHA,
        )
    )


def _display_type():
    """把配置字符串转换为Display.ST7701等常量。"""
    if not hasattr(Display, config.DISPLAY_TYPE):
        raise RuntimeError("Display type not found: {}".format(config.DISPLAY_TYPE))
    return getattr(Display, config.DISPLAY_TYPE)


def _create_detector():
    """集中创建钢球检测器，避免算法常量散落在主循环。"""
    return BallDetector(
        image_width=config.CAMERA_WIDTH,
        image_height=config.CAMERA_HEIGHT,
        roi=config.BALL_ROI,
        dp=config.BALL_CIRCLE_DP,
        min_dist=config.BALL_CIRCLE_MIN_DIST,
        param1=config.BALL_CIRCLE_PARAM1,
        param2=config.BALL_CIRCLE_PARAM2,
        min_radius=config.BALL_CIRCLE_MIN_RADIUS,
        max_radius=config.BALL_CIRCLE_MAX_RADIUS,
        expected_radius=config.BALL_EXPECTED_RADIUS,
        max_jump_px=config.BALL_TRACK_MAX_JUMP_PX,
        max_radius_change=config.BALL_TRACK_MAX_RADIUS_CHANGE,
        lost_reset_frames=config.BALL_TRACK_LOST_RESET_FRAMES,
        use_grayscale=config.BALL_GRAYSCALE_ENABLED,
    )


def _add_control_measurement(result, position_filter):
    """增加原始/滤波位置、像素误差和软件安全区状态。

    重要原则：
    - 安全判断使用本帧原始位置，避免滤波延迟掩盖越界；
    - 控制误差使用滤波位置，降低霍夫圆中心约±2 px的静止抖动；
    - 检测失败立即清空滤波器并返回None，绝不输出上一帧旧误差。
    """
    if result is None:
        position_filter.reset()
        return None

    raw_x = result["center"][0]
    filtered_value = position_filter.update(raw_x)

    # 图像坐标均为非负数，+0.5后取整可得到最接近的整数像素。
    # 保持后续UART和STM32处理全部使用整数，避免不必要的浮点传输。
    filtered_x = int(filtered_value + 0.5)

    result["raw_x"] = raw_x
    result["filtered_x"] = filtered_x
    result["raw_error_px"] = pixel_position_error(raw_x, config.BALL_TARGET_X)
    result["error_px"] = pixel_position_error(filtered_x, config.BALL_TARGET_X)
    result["ball_safe"] = position_is_safe(
        raw_x,
        config.BALL_SAFE_LEFT_X,
        config.BALL_SAFE_RIGHT_X,
    )
    return result


def _draw_status(image, result, fps, grayscale):
    """只绘制实时FPS和本帧钢球框，避免无关OSD开销。

    result为None时只显示FPS，绝不能读取上一帧坐标或访问result字段。
    灰度帧使用0~255的单通道颜色值；RGB565帧使用RGB元组。
    """
    draw_color = 255 if grayscale else (255, 255, 255)

    # 使用轻量内置英文点阵字体，避免draw_string_advanced的字体渲染开销。
    image.draw_string(
        4, 4, "FPS:{:.1f}".format(fps),
        color=draw_color, scale=2,
    )

    if result is None:
        return

    bbox_x, bbox_y, bbox_width, bbox_height = result["bbox"]
    image.draw_rectangle(
        bbox_x, bbox_y, bbox_width, bbox_height,
        color=draw_color, thickness=2,
    )



def _print_result(result, fps):
    """限频输出固定字段，方便复制现场记录。"""
    if result is None:
        print(
            "ball_valid=0 ball_safe=0 raw_x=-1 filtered_x=-1 center_y=-1 "
            "raw_error_px=0 error_px=0 radius=0 detector=none fps={:.1f}".format(fps)
        )
        return

    center_x, center_y = result["center"]
    print(
        "ball_valid=1 ball_safe={} raw_x={} filtered_x={} center_y={} "
        "raw_error_px={} error_px={} radius={} raw_circles={} "
        "tracking={} detector={} fps={:.1f}".format(
            1 if result["ball_safe"] else 0,
            result["raw_x"],
            result["filtered_x"],
            center_y,
            result["raw_error_px"],
            result["error_px"],
            result["radius"],
            result["raw_circle_count"],
            result["tracking_mode"],
            result["detector"],
            fps,
        )
    )


def run():
    """初始化摄像头/LCD/UART，循环检测并发送钢球测量。"""
    sensor = None
    vision_uart = None
    media_initialized = False
    display_initialized = False

    _apply_field_tuning()
    detector = _create_detector()
    position_filter = ExponentialFilter(config.BALL_FILTER_ALPHA)
    required_api = detector.required_api_name()
    if not detector.capability_report()[required_api]:
        raise RuntimeError("required API missing: cv_lite.{}".format(required_api))
    print("cv_lite.{}=OK".format(required_api))
    print("ball_detection=hough_circle_in_fixed_roi")
    print(
        "uart={} id={} baud={} tx_io={} rx_io={} servo=OFF".format(
            "ON" if config.UART_ENABLED else "OFF",
            config.UART_ID,
            config.UART_BAUDRATE,
            config.UART_TX_PIN,
            config.UART_RX_PIN,
        )
    )

    debug_saver = DebugFrameSaver(
        path=config.DEBUG_IMAGE_PATH,
        interval_ms=config.DEBUG_SAVE_INTERVAL_MS,
        enabled=config.DEBUG_IMAGE_ENABLED,
    )
    clock = time.clock()
    frame_count = 0

    try:
        vision_uart = VisionUart(
            uart_id=config.UART_ID,
            baudrate=config.UART_BAUDRATE,
            tx_pin=config.UART_TX_PIN,
            rx_pin=config.UART_RX_PIN,
            enabled=config.UART_ENABLED,
        )

        sensor = Sensor(width=config.CAMERA_WIDTH, height=config.CAMERA_HEIGHT)
        sensor.reset()
        sensor.set_hmirror(config.CAMERA_HMIRROR)
        sensor.set_vflip(config.CAMERA_VFLIP)
        sensor.auto_exposure(config.CAMERA_AUTO_EXPOSURE)
        sensor.set_framesize(width=config.CAMERA_WIDTH, height=config.CAMERA_HEIGHT)
        # cv_lite的灰度/RGB888圆检测函数要求输入格式与Sensor输出严格一致。
        # 灰度模式由Sensor直接产生单通道图像，不在Python循环里做格式转换。
        if config.BALL_GRAYSCALE_ENABLED:
            sensor.set_pixformat(Sensor.GRAYSCALE)
        else:
            sensor.set_pixformat(Sensor.RGB888)

        Display.init(
            _display_type(),
            to_ide=config.DISPLAY_TO_IDE,
        )
        display_initialized = True
        MediaManager.init()
        media_initialized = True
        sensor.run()
        time.sleep_ms(config.CAMERA_WARMUP_MS)

        log_info("Steel-ball static test started")
        log_info("ROI: {}".format(config.BALL_ROI))

        while True:
            clock.tick()
            frame = sensor.snapshot()
            result = _add_control_measurement(
                detector.detect(frame),
                position_filter,
            )

            # 每处理完一帧就发送一次，包括“没有找到球”的无效帧。
            # 这样STM32可以区分：通信超时、通信正常但视觉无效、球有效但越界。
            if result is None:
                # 使用位置参数避免在每帧循环中创建关键字参数对象。
                vision_uart.send_measurement(False, False, 0, -1)
            else:
                vision_uart.send_measurement(
                    True,
                    result["ball_safe"],
                    result["error_px"],
                    result["filtered_x"],
                )

            if config.BALL_GRAYSCALE_ENABLED:
                # 直接在1字节/像素的灰度Sensor帧上画灰度标记。
                # 不调用to_rgb565()，因此没有灰度缓冲扩展和额外整帧转换。
                display_frame = frame
            else:
                # RGB888回退模式仍转换为RGB565后再显示。
                display_frame = frame.to_rgb565()
            _draw_status(
                display_frame,
                result,
                clock.fps(),
                config.BALL_GRAYSCALE_ENABLED,
            )
            # 使用Yahboom官方例程已验证的ST7701默认显示尺寸和默认原点。
            # 不强制创建800x480显示层，避免IDE可见但脱机LCD没有画面。
            Display.show_image(display_frame)

            if frame_count % config.CONSOLE_INTERVAL_FRAMES == 0:
                _print_result(result, clock.fps())
            if result is not None:
                debug_saver.save_if_due(display_frame)

            frame_count += 1
            if frame_count >= config.GC_INTERVAL_FRAMES:
                gc.collect()
                frame_count = 0
            os.exitpoint()

    except KeyboardInterrupt:
        log_info("Stopped by user")
    except BaseException as exc:
        log_error("Fatal error: {}".format(exc))
        raise
    finally:
        if vision_uart is not None:
            try:
                vision_uart.deinit()
            except BaseException:
                pass
        if sensor is not None:
            try:
                sensor.stop()
            except BaseException:
                pass
        if display_initialized:
            Display.deinit()
        os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
        time.sleep_ms(100)
        if media_initialized:
            MediaManager.deinit()
        log_info("Resources released")


if __name__ == "__main__":
    os.exitpoint(os.EXITPOINT_ENABLE)
    run()
